from django.apps import AppConfig


class ParkConfig(AppConfig):
    name = 'park'
