from django.contrib import admin


from .models import *

# Register your models here.
admin.site.register(Register)

admin.site.register(Sensorstatesupdate)

admin.site.register(Humidityupdate)

admin.site.register(Streetlightings)

admin.site.register(FeedbackForm)

admin.site.register(AdminUpdates)

admin.site.register(sprinklerstatus)

admin.site.register(Humidityupdation)

admin.site.register(alarmupdate)




